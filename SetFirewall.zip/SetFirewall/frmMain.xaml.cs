﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using NetFwTypeLib;

namespace SetFirewall
{
    /// <summary>
    /// MainWindow.xaml에 대한 상호 작용 논리
    /// </summary>
    public partial class MainWindow : Window
    {
        xFirewall firewall = new xFirewall();

        public MainWindow()
        {
            InitializeComponent();
        }

        private void gridTop_MouseDown(object sender, MouseButtonEventArgs e)
        {
            if (e.LeftButton == MouseButtonState.Pressed)
            {
                DragMove();
            }
        }

        private void Window_ContentRendered(object sender, EventArgs e)
        {
            // firewall.GetFirewallInfo();
            var firewallEnable = firewall.GetFirewallEnable();

            var item = firewall.GetFwAllowAppInfo("Agent DVR");

        }

        private void togUseFirewall_Checked(object sender, RoutedEventArgs e)
        {
            if (txtUseFirewall != null)
            {
                //firewall.IsFirewallEnable = true;
                //if (firewall.IsFirewallEnable == true) txtUseFirewall.Text = "방화벽 사용";
            }
        }

        private void togUseFirewall_Unchecked(object sender, RoutedEventArgs e)
        {
            if (txtUseFirewall != null)
            {
                //firewall.IsFirewallEnable = false;
                //if (firewall.IsFirewallEnable == false) txtUseFirewall.Text = "방화벽 해제";
            }   
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            
        }
    }
}
